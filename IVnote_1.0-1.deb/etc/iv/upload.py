#!/usr/bin/env python
from os.path import basename
# coding=utf-8
""" Upload a recorded call with metadata """

import base64
import contextlib
import datetime
import json
import logging
import os
import subprocess
import sys
import urllib2
# from datetime import datetime
import decimal

group_id = 151
recordings_location = "/var/spool/asterisk/monitor"
recordings_location = 'C:/Users/colinp/Desktop/IVNote'  # DEBUG

server_file = "/etc/raspap/recorder/iv.conf"
with open(server_file, 'r') as myfile:
    server=myfile.read()

BASIC_AUTH = "tommy:tomcat"  # username:password or blank string ("") to disable
# IV uses a self-signed certificate by default.  If using a trusted cert you can put None instead of a path string.
cafile = "/home/pi/scripts/ca-cert.pem"
ws_path = "{}:8443/vrxServlet/ws/VRXService/vrxServlet/".format(server)


def http_request(url, data):
    try:
        req = urllib2.Request(url, data, {'Content-Type': 'application/json'})
        if BASIC_AUTH:
            req.add_header("Authorization", "Basic %s" % base64.encodestring(BASIC_AUTH).replace('\n', ''))
        if sys.version_info >= (2, 7, 9):
            opened_url = urllib2.urlopen(req, cafile=cafile)
        else:
            opened_url = urllib2.urlopen(req)
        with contextlib.closing(opened_url) as f:
            return f.read()
    except urllib2.HTTPError, e:
        logging.error('Problem sending to url {}:\nError {}\n{}'.format(e.url, e.msg, e.read()), exc_info=1)


def external(cmd):
    logging.debug(" ".join(cmd))
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT)
    except subprocess.CalledProcessError, cpe:
        logging.error('{}\n{}\n{}'.format(cpe.args, cpe.returncode, cpe.output), exc_info=1)


def filename_to_metadata(filename, duration):
#out-07711141314-2403377e0-07770431776-20160715-123657-1468586217.1648.mix.wav
    e, salesperson_id, inbound_route, inbound_caller_id, date, time, uid = filename.split('--')
    date_object = datetime.datetime.strptime(date + " " + time, '%Y%m%d %H%M%S')

    with open(filename, "rb") as file_to_base64:
        item = {
            "Item": {
                "base64Audio": base64.b64encode(file_to_base64.read()),
                "title": "[IV Note] Telephone Call ({})".format(str(datetime.timedelta(seconds=int(duration)))),
                "EVDate": date_object.isoformat(),
                "EVTo": {"SMTPAddress": '{}@example.com'.format(inbound_caller_id), "displayName": inbound_caller_id},
                "EVSubject": "[IV Note] Telephone Call ({})".format(str(datetime.timedelta(seconds=int(duration)))),
                "EVFrom": {"SMTPAddress": '{}@example.com'.format(salesperson_id), "displayName": salesperson_id},
                "vox": 1  # 1 is audio
            }
        }
        return item


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG,
                        format='%(asctime)s %(levelname)s %(module)s:%(lineno)s %(funcName)s : %(message)s')
    combined = sys.argv[1];
    combined_duration = decimal.Decimal(external(["sox", "--info", "-D", combined]))
    logging.debug("creating API request")
    encoded_item = filename_to_metadata(combined, combined_duration)
    logging.debug("uploading {} recording...")
    response = http_request("{}indexNewItem/{}".format(ws_path, group_id), json.dumps(encoded_item))
    # Check the result of sending the item
    returned_item = json.loads(response)
    logging.debug("successfully uploaded as item {}".format(returned_item[u'Item'][u'id']))
if returned_item[u'Item'][u'id'] is not None:
    print format(returned_item[u'Item'][u'id'])
else:
    print "FAILED"	
