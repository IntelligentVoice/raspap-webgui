#!/usr/bin/perl
#liblinux-inotify2-perl
#inotofy-tools
use POSIX();
use File::Basename;
use File::Copy;
use Linux::Inotify2;
 # create a new object
my $phone_number="1241592e8";
my $dirs="/etc/iv/audio/";

  my $inotify = new Linux::Inotify2
        or die "Unable to create new inotify object: $!" ;


    # create watch

$inotify->watch("/etc/iv/audio",  IN_MOVED_TO, \&watch_new);


1 while $inotify->poll;


    sub watch_new {
       my $e = shift;
	   my $filename=$e->fullname;
	   print "New file or dir: " . $filename . "\n";
	if ($filename=~/\.wav$/)
	{my $x=`python /etc/iv/upload.py $filename 2>/dev/null`;
   if ($x=~/\d+/){## it is uploaded
   unlink $filename;
print "REMOVED $x\n";
}
else{
rename $filename, $filename.".FAIL";
}   
}


       

           }
